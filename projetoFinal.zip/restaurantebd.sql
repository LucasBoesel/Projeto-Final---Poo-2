CREATE DATABASE  IF NOT EXISTS `restaurantebd` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `restaurantebd`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: restaurantebd
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbcargo`
--

DROP TABLE IF EXISTS `tbcargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbcargo` (
  `pkCargo` int(11) NOT NULL AUTO_INCREMENT,
  `nomeCargo` varchar(50) NOT NULL,
  `salario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`pkCargo`),
  UNIQUE KEY `nomeCargo` (`nomeCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcargo`
--

LOCK TABLES `tbcargo` WRITE;
/*!40000 ALTER TABLE `tbcargo` DISABLE KEYS */;
INSERT INTO `tbcargo` VALUES (1,'Chef de Cozinha',5000.00),(2,'Cozinheiro(a)',3000.00),(3,'Garçom/Garçonete',2000.00),(4,'Atendente',1800.00),(5,'Caixa',1900.00),(6,'Lavador de Louças',1600.00),(7,'Estoquista',1700.00),(8,'Gerente',5500.00),(9,'Entregador',2000.00);
/*!40000 ALTER TABLE `tbcargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbcliente_prato_favorito`
--

DROP TABLE IF EXISTS `tbcliente_prato_favorito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbcliente_prato_favorito` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fkCliente` int(11) DEFAULT NULL,
  `fkPrato` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fkCliente` (`fkCliente`),
  KEY `fkPrato` (`fkPrato`),
  CONSTRAINT `tbcliente_prato_favorito_ibfk_1` FOREIGN KEY (`fkCliente`) REFERENCES `tbusuario` (`pkUsuario`),
  CONSTRAINT `tbcliente_prato_favorito_ibfk_2` FOREIGN KEY (`fkPrato`) REFERENCES `tbprato` (`pkPrato`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbcliente_prato_favorito`
--

LOCK TABLES `tbcliente_prato_favorito` WRITE;
/*!40000 ALTER TABLE `tbcliente_prato_favorito` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbcliente_prato_favorito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbfuncionario`
--

DROP TABLE IF EXISTS `tbfuncionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbfuncionario` (
  `pkFuncionario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(40) NOT NULL,
  `dataNasc` date DEFAULT NULL,
  `fkCargo` int(11) DEFAULT 1,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`pkFuncionario`),
  UNIQUE KEY `email` (`email`),
  KEY `fkCargo` (`fkCargo`),
  CONSTRAINT `tbfuncionario_ibfk_1` FOREIGN KEY (`fkCargo`) REFERENCES `tbcargo` (`pkCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbfuncionario`
--

LOCK TABLES `tbfuncionario` WRITE;
/*!40000 ALTER TABLE `tbfuncionario` DISABLE KEYS */;
INSERT INTO `tbfuncionario` VALUES (3,'Carlos','ca@gmail.com','7c4a8d09ca3762af61e59520943dc26494f8941b','2003-03-29',1,1);
/*!40000 ALTER TABLE `tbfuncionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbprato`
--

DROP TABLE IF EXISTS `tbprato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbprato` (
  `pkPrato` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pkPrato`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbprato`
--

LOCK TABLES `tbprato` WRITE;
/*!40000 ALTER TABLE `tbprato` DISABLE KEYS */;
INSERT INTO `tbprato` VALUES (1,'Feijoada'),(2,'Churrasco'),(3,'Moqueca de peixe'),(4,'Frango à parmegiana'),(5,'Lasanha'),(6,'Pizza Margherita'),(7,'Bacalhau à Brás'),(8,'Risoto de camarão'),(9,'Strogonoff de carne'),(10,'Hambúrguer gourmet');
/*!40000 ALTER TABLE `tbprato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbusuario`
--

DROP TABLE IF EXISTS `tbusuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbusuario` (
  `pkUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(40) NOT NULL,
  `dataNasc` date DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`pkUsuario`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbusuario`
--

LOCK TABLES `tbusuario` WRITE;
/*!40000 ALTER TABLE `tbusuario` DISABLE KEYS */;
INSERT INTO `tbusuario` VALUES (1,'Lucas Boesel','lb@gmail.com','7c4a8d09ca3762af61e59520943dc26494f8941b','2006-06-29',1);
/*!40000 ALTER TABLE `tbusuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-24 20:03:11
