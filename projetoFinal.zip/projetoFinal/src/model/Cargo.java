package model;

public class Cargo {

    private int pkCargo;
    private String nomeCargo;
    private double salario;

    public Cargo() {
    }

    
  
  public Cargo(int pkCargo, String nomeCargo, double salario) {
        this.pkCargo = pkCargo;
        this.nomeCargo = nomeCargo;
        this.salario = salario;
    }
  
      public int getPkCargo() {
        return pkCargo;
    }

    public void setPkCargo(int pkCargo) {
        this.pkCargo = pkCargo;
    }

    public String getNomeCargo() {
        return nomeCargo;
    }

    public void setNomeCargo(String nomeCargo) {
        this.nomeCargo = nomeCargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return nomeCargo; // Isso é essencial pra exibir o nome no JComboBox
    }
}
    
