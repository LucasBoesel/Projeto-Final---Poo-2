
package model;

public class ClientePratoFavorito {
   
   private int id;
    private int fkCliente;
    private int fkPrato;   
    
     public ClientePratoFavorito() {
    }
     
     public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
     public int getfkCliente() {
        return fkCliente;
    }

    public void setfkCliente(int fkCliente) {
        this.fkCliente = fkCliente;
    }
    
        public int getfkPrato() {
        return fkCliente;
    }

    public void getfkPrato(int getfkPrato) {
        this.fkCliente = getfkPrato;
    }
}

