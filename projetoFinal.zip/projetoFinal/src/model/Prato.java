
package model;

public class Prato {
 
    private int  pkPrato;
    private String nome;
    
 public Prato() {
    }   
 
   public Prato(int pkPrato, String nome) {
        this.pkPrato = pkPrato;
        this.nome = nome;
    }
   
     public int getPkPrato() {
        return pkPrato;
    }

    public void setPkCargo(int pkPrato) {
        this.pkPrato = pkPrato;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
      public String toString() {
        return nome;  // Exibe o nome do prato no JComboBox
    }
}
