package model;

import java.util.Date;

public class Funcionario {

    private int pkFuncionario;
    private String nome;
    private String email;
    private String senha;
    private Date dataNasc;
    private Cargo cargo;
    private boolean ativo;

    public Funcionario() {
    }

      public int getPkFuncionario() {
        return pkFuncionario;
    }

    public void setPkFuncionario(int pkFuncionario) {
        this.pkFuncionario = pkFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public Cargo getCargo() {
        return cargo;
    }
    
        public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }
    
        public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }
    
    
  public String ativoToString() {
    if(ativo){
      return "Ativo";
    } else {
      return "Inativo";
    }
  } 

    // Se quiser manter o fkCargo separado (opcional)
    public int getFkCargo() {
        return (cargo != null) ? cargo.getPkCargo() : 0;
    }

    public void setFkCargo(int fkCargo) {
        if (this.cargo == null) {
            this.cargo = new Cargo();
        }
        this.cargo.setPkCargo(fkCargo);
    }
}
