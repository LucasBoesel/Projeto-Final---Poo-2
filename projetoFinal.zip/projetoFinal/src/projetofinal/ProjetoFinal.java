
package projetofinal;

import view.FrEscolha;


public class ProjetoFinal {

    public static void main(String[] args) {
        new FrEscolha().setVisible(true);
    }
    
}
