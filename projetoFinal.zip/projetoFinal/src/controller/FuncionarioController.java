package controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Cargo;
import model.Funcionario;

public class FuncionarioController {

    public boolean inserirFuncionario(Funcionario f) {
        String sql = "INSERT INTO tbfuncionario(nome, email, senha, dataNasc, fkCargo, ativo) "
                + "VALUES (?, ?, ?, ?, ?, ?)";

        //Cria uma instância do gerenciador de conexão(conexão com o banco de dados),
        GerenciadorConexao gerenciador = new GerenciadorConexao();
        //Declara as variáveis como nulas antes do try para poder usar no finally
        PreparedStatement comando = null;

        try {
            comando = gerenciador.prepararComando(sql);
            comando.setString(1, f.getNome());
            comando.setString(2, f.getEmail());
            comando.setString(3, f.getSenha());
            comando.setDate(4, new java.sql.Date(f.getDataNasc().getTime()));
            comando.setInt(5, f.getCargo().getPkCargo());
            comando.setBoolean(6, f.isAtivo());

            comando.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao alterar funcionário: " + e.getMessage());
        } finally {
            gerenciador.fecharConexao(comando);
        }

        return false;
    }

    public List<Funcionario> consultar() {
         String sql = "SELECT f.pkFuncionario, f.nome, f.email, f.senha, f.dataNasc, "
                + "c.nomeCargo, c.salario, f.ativo "
                + "FROM tbfuncionario f "
                + "JOIN tbcargo c ON f.fkCargo = c.pkCargo";

        GerenciadorConexao gerenciador = new GerenciadorConexao();
        PreparedStatement comando = null;
        ResultSet resultado = null;
        List<Funcionario> listaFuncionarios = new ArrayList<>();

        List<Funcionario> lista = new ArrayList<>();

         try {
            comando = gerenciador.prepararComando(sql);
            resultado = comando.executeQuery();

            while (resultado.next()) {
                Funcionario f = new Funcionario();
                f.setPkFuncionario(resultado.getInt("pkFuncionario"));
                f.setNome(resultado.getString("nome"));
                f.setEmail(resultado.getString("email"));
                f.setSenha(resultado.getString("senha"));
                f.setDataNasc(resultado.getDate("dataNasc"));
                Cargo c = new Cargo();
                c.setNomeCargo(resultado.getString("nomeCargo"));
                c.setSalario(resultado.getDouble("salario"));
                f.setCargo(c);
                f.setAtivo(resultado.getBoolean("ativo"));

                lista.add(f);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao consultar funcionários: " + e.getMessage());
        } finally {
            gerenciador.fecharConexao(comando, resultado);
        }

        return lista;
    }

    public boolean alterarFuncionario(Funcionario f) {
        String sql = "UPDATE tbfuncionario SET nome = ?, "
                + " email = ?";

        if (f.getSenha() != null) {
            sql = sql + " , senha = ? ";
        }

        sql = sql + " , datanasc = ?, ativo = ? WHERE pkfuncionario = ?";

        GerenciadorConexao gerenciador = new GerenciadorConexao();
        PreparedStatement comando = null;

        try {
            comando = gerenciador.prepararComando(sql);

            comando.setString(1, f.getNome());
            comando.setString(2, f.getEmail());

            int numCampo = 3;

            if (f.getSenha() != null) {
                comando.setString(numCampo, f.getSenha()); //numCampo = 3
                numCampo++;
            }

            //numCampo = 3 ou 4
            comando.setDate(numCampo, new java.sql.Date(f.getDataNasc().getTime()));
            numCampo++;
            //numCampo = 4 ou 5
            comando.setBoolean(numCampo, f.isAtivo());
            numCampo++;
            //numCampo = 5 ou 6
            comando.setInt(numCampo, f.getPkFuncionario());

            comando.executeUpdate();

            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            gerenciador.fecharConexao(comando);
        }
        return false;
    }

    public boolean deletar(int pkFuncionario) {
        String sql = "DELETE FROM tbfuncionario WHERE pkFuncionario = ?";

        GerenciadorConexao gerenciador = new GerenciadorConexao();
        PreparedStatement comando = null;

        try {
            comando = gerenciador.prepararComando(sql);
            comando.setInt(1, pkFuncionario);

            comando.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir funcionário: " + e.getMessage());
        } finally {
            gerenciador.fecharConexao(comando);
        }

        return false;
    }

public Funcionario buscarPorPk(int pkFuncionario) {
    String sql = "SELECT * FROM tbfuncionario WHERE pkfuncionario = ?";

    GerenciadorConexao gerenciador = new GerenciadorConexao();
    PreparedStatement comando = null;
    ResultSet resultado = null;

    Funcionario func = null;

    try {
        comando = gerenciador.prepararComando(sql);
        comando.setInt(1, pkFuncionario);
        resultado = comando.executeQuery();

        if (resultado.next()) {
            func = new Funcionario();
            func.setPkFuncionario(resultado.getInt("pkfuncionario"));
            func.setNome(resultado.getString("nome"));
            func.setEmail(resultado.getString("email"));
            func.setSenha(resultado.getString("senha"));
            func.setDataNasc(resultado.getDate("datanasc"));
            func.setAtivo(resultado.getBoolean("ativo"));

            // Buscar o cargo
            int pkCargo = resultado.getInt("fkCargo");
            CargoController cargoController = new CargoController();
            Cargo cargo = cargoController.buscarCargoPorId(pkCargo);
            func.setCargo(cargo); // ⚠ isso aqui é essencial!
        }

    } catch (SQLException ex) {
        Logger.getLogger(FuncionarioController.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        gerenciador.fecharConexao(comando, resultado);
    }

    return func;
}

    public Funcionario buscarFuncionarioPorEmailESenha(String email, String senha) {
        String sql = "SELECT * FROM tbfuncionario WHERE email = ? AND senha = ?";

        GerenciadorConexao gerenciador = new GerenciadorConexao();
        PreparedStatement comando = null;
        ResultSet resultado = null;

        try {
            comando = gerenciador.prepararComando(sql);
            comando.setString(1, email);
            comando.setString(2, senha);
            resultado = comando.executeQuery();

            if (resultado.next()) {
                Funcionario f = new Funcionario();
                f.setPkFuncionario(resultado.getInt("pkFuncionario"));
                f.setNome(resultado.getString("nome"));
                f.setEmail(resultado.getString("email"));
                f.setSenha(resultado.getString("senha"));
                f.setDataNasc(resultado.getDate("dataNasc"));
                f.setFkCargo(resultado.getInt("fkCargo"));
                f.setAtivo(resultado.getBoolean("ativo"));
                return f;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar funcionário: " + e.getMessage());
        } finally {
            gerenciador.fecharConexao(comando, resultado);
        }

        return null;
    }
}
