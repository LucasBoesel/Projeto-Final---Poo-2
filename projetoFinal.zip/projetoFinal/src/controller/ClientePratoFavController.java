
package controller;


public class ClientePratoFavController {
    
}
