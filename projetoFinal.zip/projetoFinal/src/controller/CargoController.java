
package controller;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import model.Cargo;

public class CargoController {

    private Connection connection;
    
    public boolean inserirCargo(Cargo cargo) {
        String sql = "INSERT INTO cargos (nome, salario) VALUES (?, ?)";

        GerenciadorConexao gerenciador = new GerenciadorConexao();
        PreparedStatement comando = null;

        try {
            comando = gerenciador.prepararComando(sql);
            comando.setString(1, cargo.getNomeCargo());
            comando.setDouble(2, cargo.getSalario());

            comando.executeUpdate();
            return true;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir cargo: " + e.getMessage());
        } finally {
            gerenciador.fecharConexao(comando);
        }

        return false;
    } 
      
    public List<Cargo> listarCargos() {
    List<Cargo> cargos = new ArrayList<>();
    String sql = "SELECT * FROM tbcargo";

    GerenciadorConexao gerenciador = new GerenciadorConexao();
    PreparedStatement comando = null;
    ResultSet rs = null;

    try {
        comando = gerenciador.prepararComando(sql);
        rs = comando.executeQuery();

        while (rs.next()) {
            Cargo cargo = new Cargo();
            cargo.setPkCargo(rs.getInt("pkCargo")); 
            cargo.setNomeCargo(rs.getString("nomeCargo")); 
            cargo.setSalario(rs.getDouble("salario"));
            cargos.add(cargo);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        gerenciador.fecharConexao(comando, rs);
    }

    return cargos;
}
    

    public Cargo buscarCargoPorId(int pkCargo) {
    String sql = "SELECT * FROM tbcargo WHERE pkCargo = ?";

    GerenciadorConexao gerenciador = new GerenciadorConexao();
    PreparedStatement comando = null;
    ResultSet resultado = null;

    try {
        comando = gerenciador.prepararComando(sql);
        comando.setInt(1, pkCargo);
        resultado = comando.executeQuery();

        if (resultado.next()) {
            Cargo cargo = new Cargo();
            cargo.setPkCargo(resultado.getInt("pkCargo"));
            cargo.setNomeCargo(resultado.getString("nomeCargo"));
            cargo.setSalario(resultado.getDouble("salario"));
            return cargo;
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Erro ao buscar cargo: " + e.getMessage());
    } finally {
        gerenciador.fecharConexao(comando, resultado);
    }

    return null;
}
}
    

