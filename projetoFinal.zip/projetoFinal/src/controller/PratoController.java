package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Prato;

public class PratoController {

  private Connection connection; 
  
  
    public List<Prato> listarPratos() {
    List<Prato> pratos = new ArrayList<>();
    String sql = "SELECT * FROM tbprato";

    GerenciadorConexao gerenciador = new GerenciadorConexao();
    PreparedStatement comando = null;
    ResultSet rs = null;

    try {
        comando = gerenciador.prepararComando(sql);
        rs = comando.executeQuery();

        while (rs.next()) {
            Prato prato = new Prato();
            prato.setPkCargo(rs.getInt("pkPrato")); 
            prato.setNome(rs.getString("nome")); 
            pratos.add(prato);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        gerenciador.fecharConexao(comando, rs);
    }

    return pratos;
}
}
