package view;

import controller.FuncionarioController;
import controller.UsuarioController;
import java.awt.event.KeyEvent;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import model.Funcionario;
import model.Usuario;
import utils.Utils;

public class FrLogin extends javax.swing.JDialog {

    private String tipoUsuario;


    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public FrLogin(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setTitle("Sabor & Arte - Login");
        this.setLocationRelativeTo(null);

        edtEmail.setText("");
        edtSenha.setText("");

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblAutenticacao = new javax.swing.JLabel();
        edtEmail = new javax.swing.JTextField();
        edtSenha = new javax.swing.JPasswordField();
        lblEmail = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        btnVoltar = new javax.swing.JButton();
        lblImagem = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        JcbMostrarSenha = new javax.swing.JCheckBox();
        btnLogar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAutenticacao.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        lblAutenticacao.setForeground(new java.awt.Color(255, 255, 153));
        lblAutenticacao.setText("Autenticação");
        jPanel1.add(lblAutenticacao, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, -1, -1));

        edtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 304, 273, -1));

        edtSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edtSenha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                edtSenhaKeyPressed(evt);
            }
        });
        jPanel1.add(edtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 390, 273, -1));

        lblEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblEmail.setText("Email");
        jPanel1.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(113, 269, -1, -1));

        lblSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblSenha.setText("Senha");
        jPanel1.add(lblSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 360, -1, -1));

        btnVoltar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnVoltar.setText("Voltar");
        btnVoltar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnVoltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnVoltarMouseClicked(evt);
            }
        });
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });
        jPanel1.add(btnVoltar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 80, 40));
        jPanel1.add(lblImagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(188, 33, -1, -1));

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBuscarMouseClicked(evt);
            }
        });
        jPanel1.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 490, 121, 40));

        JcbMostrarSenha.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        JcbMostrarSenha.setText("Mostrar Senha");
        JcbMostrarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JcbMostrarSenhaActionPerformed(evt);
            }
        });
        jPanel1.add(JcbMostrarSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 430, 140, -1));

        btnLogar1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnLogar1.setText("Entrar");
        btnLogar1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnLogar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLogar1MouseClicked(evt);
            }
        });
        jPanel1.add(btnLogar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 490, 121, 40));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void edtSenhaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_edtSenhaKeyPressed
        //verifico se foi pressionado ENTER
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            //Se foi teclado ENTER tenta fazer login
            realizarLogin();
        }
    }//GEN-LAST:event_edtSenhaKeyPressed

    private void btnVoltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVoltarMouseClicked
        this.dispose();
        new FrEscolha().setVisible(true);
    }//GEN-LAST:event_btnVoltarMouseClicked

    private void btnBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarMouseClicked

        FrConsultar telaConsultarInfosCliente = new FrConsultar(null, rootPaneCheckingEnabled);
       telaConsultarInfosCliente.setVisible(true);
        
        if(!telaConsultarInfosCliente.getId().equals("")) {
            edtEmail.setText( telaConsultarInfosCliente.getEmail());
        } 
    }//GEN-LAST:event_btnBuscarMouseClicked

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed

    }//GEN-LAST:event_btnVoltarActionPerformed

    private boolean senhaVisivel = false;

    private void JcbMostrarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JcbMostrarSenhaActionPerformed
        senhaVisivel = !senhaVisivel;

        if (senhaVisivel) {
            edtSenha.setEchoChar((char) 0); // Mostra a senha
        } else {
            edtSenha.setEchoChar('•'); // Oculta a senha
        }
    }//GEN-LAST:event_JcbMostrarSenhaActionPerformed

    private void btnLogar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogar1MouseClicked
        realizarLogin();
    }//GEN-LAST:event_btnLogar1MouseClicked

    private void realizarLogin() {
        String email = edtEmail.getText();
        String senha = new String(edtSenha.getPassword());

        if (email.equals("")) {
            JOptionPane.showMessageDialog(null,
                    "Campo 'Email' em branco!");
            return;
        }

        if (senha.equals("")) {
            JOptionPane.showMessageDialog(null,
                    "Campo 'Senha' em branco!");
            return;
        }

        //Calcular o hash da senha
        senha = Utils.calcularHash(senha);

        UsuarioController controller = new UsuarioController();

        Usuario usuario = controller.buscarUsuarioPorEmailESenha(email, senha);

        if (usuario != null) {
            String nome = usuario.getNome();
            tipoUsuario = "cliente";
            FrMenu telaMenu = new FrMenu(nome, tipoUsuario);
            this.dispose();
            telaMenu.setVisible(true);
        } else {
            FuncionarioController funcionarioController = new FuncionarioController();
            Funcionario funcionario = funcionarioController.buscarFuncionarioPorEmailESenha(email, senha);

            if (funcionario != null) {
                String nome = funcionario.getNome();
                tipoUsuario = "funcionario";
                FrMenu telaMenu = new FrMenu(nome, tipoUsuario);
                this.dispose();
                telaMenu.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Usuário ou funcionário com senha incorretos");
            }
        }
    }

    private void formWindowOpened(java.awt.event.WindowEvent evt) {
        URL caminhoImagem = getClass().getResource("/images/logo_Waiter_Mini.png");

        if (caminhoImagem != null) {
            ImageIcon icon = new ImageIcon(caminhoImagem);
            this.setIconImage(icon.getImage());
        } else {
            System.out.println("Imagem não encontrada: /images/logo_Waiter_Mini.png");
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FrLogin dialog = new FrLogin(new javax.swing.JFrame(), true  );
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox JcbMostrarSenha;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnLogar1;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JTextField edtEmail;
    private javax.swing.JPasswordField edtSenha;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblAutenticacao;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblImagem;
    private javax.swing.JLabel lblSenha;
    // End of variables declaration//GEN-END:variables
}
