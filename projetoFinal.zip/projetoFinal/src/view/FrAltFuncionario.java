/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.CargoController;
import controller.FuncionarioController;
import java.awt.Color;
import java.net.URL;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import model.Cargo;
import model.Funcionario;
import utils.Utils;

public class FrAltFuncionario extends javax.swing.JDialog {

    private int pkFuncionario;

    public void setPkfuncionario(int pkfuncionario) {
        this.pkFuncionario = pkfuncionario;
    }

    public FrAltFuncionario(java.awt.Frame parent, boolean modal, int pkFuncionario) {
        super(parent, modal);
        initComponents();

        this.setTitle("Sabor & Arte - Alteraração do Funcionário");
        this.setLocationRelativeTo(null);

        setPkfuncionario(pkFuncionario);
        carregarFuncionario();

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        edtCodigo = new javax.swing.JTextField();
        edtEmail = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        lblConfirmaSenha = new javax.swing.JLabel();
        lblDataNasc = new javax.swing.JLabel();
        edtConfirmaSenha = new javax.swing.JPasswordField();
        edtSenha = new javax.swing.JPasswordField();
        edtDataNasc = new javax.swing.JFormattedTextField();
        chkAtivo = new javax.swing.JCheckBox();
        btnAlterarSenha = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblNome = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        lblNomeLogo = new javax.swing.JLabel();
        edtNome = new javax.swing.JTextField();
        lblCodigo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        edtCodigo.setEditable(false);
        edtCodigo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 90, -1));

        edtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 300, 380, -1));

        lblEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblEmail.setText("Email");
        jPanel1.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, -1, -1));

        lblSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblSenha.setText("Senha");
        jPanel1.add(lblSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, -1, -1));

        lblConfirmaSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblConfirmaSenha.setText("Confirma senha");
        jPanel1.add(lblConfirmaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 410, -1, -1));

        lblDataNasc.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblDataNasc.setText("Data de Nascimento");
        jPanel1.add(lblDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 480, -1, -1));

        edtConfirmaSenha.setEditable(false);
        edtConfirmaSenha.setBackground(java.awt.Color.gray);
        edtConfirmaSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtConfirmaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 440, 260, -1));

        edtSenha.setEditable(false);
        edtSenha.setBackground(java.awt.Color.gray);
        edtSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 260, -1));

        edtDataNasc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));
        edtDataNasc.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 510, 160, -1));

        chkAtivo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        chkAtivo.setText("Ativo");
        jPanel1.add(chkAtivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 500, -1, -1));

        btnAlterarSenha.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnAlterarSenha.setText("Alterar senha");
        btnAlterarSenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAlterarSenhaMouseClicked(evt);
            }
        });
        jPanel1.add(btnAlterarSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 400, 140, -1));

        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCancelarMouseClicked(evt);
            }
        });
        jPanel1.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 570, 140, -1));

        lblNome.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblNome.setText("Nome");
        jPanel1.add(lblNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        btnSalvar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalvarMouseClicked(evt);
            }
        });
        jPanel1.add(btnSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 570, 140, -1));

        lblNomeLogo.setFont(new java.awt.Font("Bell MT", 1, 36)); // NOI18N
        lblNomeLogo.setText("Alteração do Funcionário");
        jPanel1.add(lblNomeLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        edtNome.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 380, -1));

        lblCodigo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblCodigo.setText("Código");
        jPanel1.add(lblCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 620, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void carregarFuncionario() {
        FuncionarioController controller = new FuncionarioController();
        Funcionario funcionario = controller.buscarPorPk(pkFuncionario);

        edtCodigo.setText(String.valueOf(funcionario.getPkFuncionario()));
        edtNome.setText(funcionario.getNome());
        edtEmail.setText(funcionario.getEmail());
        edtDataNasc.setText(Utils.converterDateToString(funcionario.getDataNasc()));
        chkAtivo.setSelected(funcionario.isAtivo());

    }


    private void btnAlterarSenhaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAlterarSenhaMouseClicked
        if (edtSenha.isEditable() == false) {
            edtSenha.setEditable(true);
            edtConfirmaSenha.setEditable(true);
            edtSenha.setBackground(Color.white);
            edtConfirmaSenha.setBackground(Color.white);
            btnAlterarSenha.setText("Cancelar alteração");

            edtSenha.setText("");
            edtConfirmaSenha.setText("");
        } else {
            edtSenha.setEditable(false);
            edtConfirmaSenha.setEditable(false);
            edtSenha.setBackground(Color.gray);
            edtConfirmaSenha.setBackground(Color.gray);
            btnAlterarSenha.setText("Alterar Senha");

            edtSenha.setText("");
            edtConfirmaSenha.setText("");
        }
    }//GEN-LAST:event_btnAlterarSenhaMouseClicked

    private void btnCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelarMouseClicked
        this.dispose();
    }//GEN-LAST:event_btnCancelarMouseClicked

    private void btnSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalvarMouseClicked
        if (verificarCampos()) {
            gravar();
        }
    }//GEN-LAST:event_btnSalvarMouseClicked

    public void gravar() {
        Funcionario funcionario = new Funcionario();
        funcionario.setPkFuncionario(pkFuncionario);
        funcionario.setNome(edtNome.getText());
        funcionario.setEmail(edtEmail.getText());

        if (edtSenha.isEditable()) {
            String senha = new String(edtSenha.getPassword());
            String senhaHash = Utils.calcularHash(senha);
            funcionario.setSenha(senhaHash);
        }

        funcionario.setDataNasc(Utils.converterStringToDate(edtDataNasc.getText()));
        funcionario.setAtivo(chkAtivo.isSelected());

        FuncionarioController controller = new FuncionarioController();

        if (controller.alterarFuncionario(funcionario)) {
            JOptionPane.showMessageDialog(null,
                    "Usuário: " + funcionario.getNome()
                    + " alterado com sucesso!");
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(null,
                    "Usuário não será alterado!");
        }
    }

    public boolean verificarCampos() {
        if (edtNome.getText().equals("")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Nome' em branco");
            return false;
        }

        if (!edtNome.getText().matches("^[\\p{L} ]+$")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Nome' possui caracteres inválidos");
            return false;
        }

        if (edtEmail.getText().equals("")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Email' em branco");
            return false;
        }
        if (!edtEmail.getText().matches(
                "^[a-z0-9.-]+@[a-z.]+.[a-z._]+$")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Email' possui formato inválido");
            return false;
        }

        if (!edtDataNasc.getText().matches(
                "^[0-9]{2}/[0-9]{2}/[0-9]{4}$")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Data Nascimento' possui formato inválido."
                    + " Ex: 01/01/2010");
            return false;
        }

        if (edtSenha.isEditable()) {
            String senha = new String(edtSenha.getPassword());

            if (senha.length() < 6) {
                JOptionPane.showMessageDialog(null,
                        "O campo 'Senha' deve ser maior que 6 caracteres");
                return false;
            }

            if (!senha.equals(new String(edtConfirmaSenha.getPassword()))) {
                JOptionPane.showMessageDialog(null,
                        "As senhas não são iguais");
                return false;
            }

        }

        return true;
    }

    private void formWindowOpened(java.awt.event.WindowEvent evt) {
        URL caminhoImagem = getClass().getResource("/images/logo_Waiter_Mini.png");

        if (caminhoImagem != null) {
            ImageIcon icon = new ImageIcon(caminhoImagem);
            this.setIconImage(icon.getImage());
        } else {
            System.out.println("Imagem não encontrada: /images/logo_logo_mini.png");
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrAltFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrAltFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrAltFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrAltFuncionario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FrAltFuncionario dialog = new FrAltFuncionario(new javax.swing.JFrame(), true, 0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterarSenha;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JTextField edtCodigo;
    private javax.swing.JPasswordField edtConfirmaSenha;
    private javax.swing.JFormattedTextField edtDataNasc;
    private javax.swing.JTextField edtEmail;
    private javax.swing.JTextField edtNome;
    private javax.swing.JPasswordField edtSenha;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCodigo;
    private javax.swing.JLabel lblConfirmaSenha;
    private javax.swing.JLabel lblDataNasc;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblNomeLogo;
    private javax.swing.JLabel lblSenha;
    // End of variables declaration//GEN-END:variables
}
