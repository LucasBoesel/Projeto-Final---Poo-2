package view;

import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class FrMenu extends javax.swing.JFrame {

    public FrMenu(String nome, String tipo) {
        initComponents();
        this.setTitle("Sabor & Arte - Menu " + tipo);
        this.setLocationRelativeTo(null);

        lblNome.setText("Bem-vindo, " + nome);
        
    if (tipo.equalsIgnoreCase("cliente")) {
        // Impede o cliente de acessar a área de funcionário
        meFuncionario.setEnabled(false);  // Desabilita o menu de funcionário
        meFuncionario.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Você não tem permissão para acessar essa área.");
        });
    } else if (tipo.equalsIgnoreCase("funcionario")) {
        // Impede o funcionário de acessar a área de cliente
        meCliente.setEnabled(false);  // Desabilita o menu de cliente
        meCliente.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Você não tem permissão para acessar essa área.");
        });
    }
        
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem2 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        lblNome = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        meCliente = new javax.swing.JMenu();
        MiCadCliente = new javax.swing.JMenuItem();
        MiConCliente = new javax.swing.JMenuItem();
        MiPratoFavorito = new javax.swing.JMenuItem();
        MiSair = new javax.swing.JMenuItem();
        meFuncionario = new javax.swing.JMenu();
        MiCadFuncionario = new javax.swing.JMenuItem();
        MiConFuncionario = new javax.swing.JMenuItem();
        MiSair1 = new javax.swing.JMenuItem();

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 51, 51));

        lblNome.setFont(new java.awt.Font("Bell MT", 1, 24)); // NOI18N
        lblNome.setForeground(new java.awt.Color(255, 255, 153));
        lblNome.setText("Bem vindo");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logo_Waiter.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(lblNome)))
                .addContainerGap(200, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(lblNome)
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addContainerGap(207, Short.MAX_VALUE))
        );

        meCliente.setText("Cliente");
        meCliente.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N

        MiCadCliente.setText("Cadastrar");
        MiCadCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MiCadClienteMouseClicked(evt);
            }
        });
        MiCadCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiCadClienteActionPerformed(evt);
            }
        });
        meCliente.add(MiCadCliente);

        MiConCliente.setText("Consultar");
        MiConCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MiConClienteMouseClicked(evt);
            }
        });
        MiConCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiConClienteActionPerformed(evt);
            }
        });
        meCliente.add(MiConCliente);

        MiPratoFavorito.setText("Cadastro Prato ");
        MiPratoFavorito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiPratoFavoritoActionPerformed(evt);
            }
        });
        meCliente.add(MiPratoFavorito);

        MiSair.setText("Sair");
        MiSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiSairActionPerformed(evt);
            }
        });
        meCliente.add(MiSair);

        jMenuBar1.add(meCliente);

        meFuncionario.setText("Funcionario");
        meFuncionario.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N

        MiCadFuncionario.setText("Cadastrar");
        MiCadFuncionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MiCadFuncionarioMouseClicked(evt);
            }
        });
        MiCadFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiCadFuncionarioActionPerformed(evt);
            }
        });
        meFuncionario.add(MiCadFuncionario);

        MiConFuncionario.setText("Consultar");
        MiConFuncionario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MiConFuncionarioMouseClicked(evt);
            }
        });
        MiConFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiConFuncionarioActionPerformed(evt);
            }
        });
        meFuncionario.add(MiConFuncionario);

        MiSair1.setText("Sair");
        MiSair1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MiSair1ActionPerformed(evt);
            }
        });
        meFuncionario.add(MiSair1);

        jMenuBar1.add(meFuncionario);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MiCadClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiCadClienteActionPerformed
        FrCadastroCliente telaCadastroCliente = new FrCadastroCliente(this, rootPaneCheckingEnabled);
        this.dispose();
        telaCadastroCliente.setVisible(true);
    }//GEN-LAST:event_MiCadClienteActionPerformed

    private void MiConClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiConClienteMouseClicked

    }//GEN-LAST:event_MiConClienteMouseClicked

    private void MiCadClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiCadClienteMouseClicked

    }//GEN-LAST:event_MiCadClienteMouseClicked

    private void MiConClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiConClienteActionPerformed
        FrConsultaCliente telaConsultaCliente = new FrConsultaCliente(this, rootPaneCheckingEnabled);
        this.dispose();
        telaConsultaCliente.setVisible(true);
    }//GEN-LAST:event_MiConClienteActionPerformed

    private void MiSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiSairActionPerformed
        this.dispose();
        new FrEscolha().setVisible(true);
    }//GEN-LAST:event_MiSairActionPerformed

    private void MiCadFuncionarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiCadFuncionarioMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_MiCadFuncionarioMouseClicked

    private void MiCadFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiCadFuncionarioActionPerformed
        FrCadastroFuncionario telaCadastroFuncionario = new FrCadastroFuncionario(this, rootPaneCheckingEnabled);
        this.dispose();
        telaCadastroFuncionario.setVisible(true);
    }//GEN-LAST:event_MiCadFuncionarioActionPerformed

    private void MiConFuncionarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MiConFuncionarioMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_MiConFuncionarioMouseClicked

    private void MiConFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiConFuncionarioActionPerformed
         FrConsultaFuncionario telaConsultaFuncionario = new FrConsultaFuncionario(this, rootPaneCheckingEnabled);
        this.dispose();
        telaConsultaFuncionario.setVisible(true);
    }//GEN-LAST:event_MiConFuncionarioActionPerformed

    private void MiSair1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiSair1ActionPerformed
        this.dispose();
        new FrEscolha().setVisible(true);
    }//GEN-LAST:event_MiSair1ActionPerformed

    private void MiPratoFavoritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MiPratoFavoritoActionPerformed
        FrCadastroPratoFav telaPratoCadFav = new FrCadastroPratoFav(this, rootPaneCheckingEnabled);
        this.dispose();
        telaPratoCadFav.setVisible(true);
    }//GEN-LAST:event_MiPratoFavoritoActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {
        URL caminhoImagem = getClass().getResource("/images/logo_Waiter_Mini.png");

        if (caminhoImagem != null) {
            ImageIcon icon = new ImageIcon(caminhoImagem);
            this.setIconImage(icon.getImage());
        } else {
            System.out.println("Imagem não encontrada: /images/logo_logo_mini.png");
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        String nome = "Usuário Exemplo";
        String tipo = "Exemplo";
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrMenu(nome, tipo).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MiCadCliente;
    private javax.swing.JMenuItem MiCadFuncionario;
    private javax.swing.JMenuItem MiConCliente;
    private javax.swing.JMenuItem MiConFuncionario;
    private javax.swing.JMenuItem MiPratoFavorito;
    private javax.swing.JMenuItem MiSair;
    private javax.swing.JMenuItem MiSair1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblNome;
    private javax.swing.JMenu meCliente;
    private javax.swing.JMenu meFuncionario;
    // End of variables declaration//GEN-END:variables
}
