package view;

import controller.UsuarioController;
import java.net.URL;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import model.Usuario;
import utils.Utils;

/**
 *
 * @author aluno.saolucas
 */
public class FrCadastroCliente extends javax.swing.JDialog {

    /**
     * Creates new form CadastroUsuario
     */
    public FrCadastroCliente(java.awt.Frame parent, boolean modal) {

        super(parent, modal);
        initComponents();
        this.setTitle("Sabor & Arte - Cadastro");
        this.setLocationRelativeTo(null);

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        btnSenha.setFocusPainted(false);
        btnSenha.setBorderPainted(false);
        btnSenha.setContentAreaFilled(false);
        btnSenha.setToolTipText("Mostrar senha");
        btnSenha.setBorder(null);
        btnSenha.setOpaque(false);
        btnConfirmaSenha.setFocusPainted(false);
        btnConfirmaSenha.setBorderPainted(false);
        btnConfirmaSenha.setContentAreaFilled(false);
        btnConfirmaSenha.setToolTipText("Mostrar senha");
        btnConfirmaSenha.setBorder(null);
        btnConfirmaSenha.setOpaque(false);

        edtNome.addActionListener(e -> edtEmail.requestFocus());
        edtEmail.addActionListener(e -> edtSenha.requestFocus());
        edtSenha.addActionListener(e -> edtConfirmaSenha.requestFocus());
        edtConfirmaSenha.addActionListener(e -> edtDataNasc.requestFocus());
        edtDataNasc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == java.awt.event.KeyEvent.VK_ENTER) {
                    if (verificarCampos()) {
                        gravar();
                    }
                }
            }
        });

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblTitulo = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        edtNome = new javax.swing.JTextField();
        edtEmail = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        lblSenha = new javax.swing.JLabel();
        lblConfirmaSenha = new javax.swing.JLabel();
        lblDataNasc = new javax.swing.JLabel();
        edtConfirmaSenha = new javax.swing.JPasswordField();
        edtSenha = new javax.swing.JPasswordField();
        edtDataNasc = new javax.swing.JFormattedTextField();
        chkAtivo = new javax.swing.JCheckBox();
        btnSalvar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnSenha = new javax.swing.JButton();
        btnConfirmaSenha = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTitulo.setFont(new java.awt.Font("Bell MT", 1, 36)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 153));
        lblTitulo.setText("Cadastro de Cliente");
        jPanel1.add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 350, -1));

        lblNome.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblNome.setText("Nome");
        jPanel1.add(lblNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        edtNome.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edtNome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(edtNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 380, -1));

        edtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edtEmail.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(edtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 380, -1));

        lblEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblEmail.setText("Email");
        jPanel1.add(lblEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, -1, -1));

        lblSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblSenha.setText("Senha");
        jPanel1.add(lblSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        lblConfirmaSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblConfirmaSenha.setText("Confirma senha");
        jPanel1.add(lblConfirmaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, -1, -1));

        lblDataNasc.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblDataNasc.setText("Data de Nascimento");
        jPanel1.add(lblDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, -1, -1));

        edtConfirmaSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edtConfirmaSenha.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(edtConfirmaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, 260, -1));

        edtSenha.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edtSenha.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        edtSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edtSenhaActionPerformed(evt);
            }
        });
        jPanel1.add(edtSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 320, 260, -1));

        edtDataNasc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        edtDataNasc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));
        edtDataNasc.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(edtDataNasc, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 460, 160, -1));

        chkAtivo.setBackground(new java.awt.Color(255, 255, 255));
        chkAtivo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        chkAtivo.setText("Ativo");
        chkAtivo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(chkAtivo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 460, -1, -1));

        btnSalvar.setBackground(new java.awt.Color(255, 255, 255));
        btnSalvar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSalvarMouseClicked(evt);
            }
        });
        jPanel1.add(btnSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 530, 140, 40));

        btnCancelar.setBackground(new java.awt.Color(255, 255, 255));
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        btnCancelar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnCancelarMouseClicked(evt);
            }
        });
        jPanel1.add(btnCancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 530, 140, 40));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, -1, -1));

        btnSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/olho_Aberto.png"))); // NOI18N
        btnSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSenhaActionPerformed(evt);
            }
        });
        jPanel1.add(btnSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        btnConfirmaSenha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/olho_Aberto.png"))); // NOI18N
        btnConfirmaSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmaSenhaActionPerformed(evt);
            }
        });
        jPanel1.add(btnConfirmaSenha, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 390, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 620, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSalvarMouseClicked

        if (verificarCampos()) {
            gravar();
        }

    }//GEN-LAST:event_btnSalvarMouseClicked

    private void btnCancelarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCancelarMouseClicked
        this.dispose();
        new FrEscolha().setVisible(true);
    }//GEN-LAST:event_btnCancelarMouseClicked

    private void edtSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edtSenhaActionPerformed

    }//GEN-LAST:event_edtSenhaActionPerformed

    private boolean senhaVisivel = false;

    private void btnSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSenhaActionPerformed
        senhaVisivel = !senhaVisivel;

        if (senhaVisivel) {
            edtSenha.setEchoChar((char) 0); // Mostra a senha
            btnSenha.setToolTipText("Ocultar senha");
            btnSenha.setIcon(new ImageIcon(getClass().getResource("/images/olho_fechado.png")));
        } else {
            edtSenha.setEchoChar('•'); // Oculta a senha
            btnSenha.setToolTipText("Mostrar senha");
            btnSenha.setIcon(new ImageIcon(getClass().getResource("/images/olho_Aberto.png")));
        }
    }//GEN-LAST:event_btnSenhaActionPerformed
     
    private boolean confirmaSenhaVisivel = false;
    
    private void btnConfirmaSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmaSenhaActionPerformed
         confirmaSenhaVisivel = ! confirmaSenhaVisivel;

        if ( confirmaSenhaVisivel) {
            edtConfirmaSenha.setEchoChar((char) 0); // Mostra a senha
            btnConfirmaSenha.setToolTipText("Ocultar senha");
            btnConfirmaSenha.setIcon(new ImageIcon(getClass().getResource("/images/olho_fechado.png")));
        } else {
            edtConfirmaSenha.setEchoChar('•'); // Oculta a senha
            btnConfirmaSenha.setToolTipText("Mostrar senha");
            btnConfirmaSenha.setIcon(new ImageIcon(getClass().getResource("/images/olho_Aberto.png")));
        }
    }//GEN-LAST:event_btnConfirmaSenhaActionPerformed

    public void gravar() {
        //criar uma instância da classe Usuario 
        //vou preencher os campos
        Usuario usu = new Usuario();

        String lSenha = new String(edtSenha.getPassword());
        String lHashSenha = Utils.calcularHash(lSenha);

        //conversão de String para Date
        Date dataNasc = Utils.converterStringToDate(edtDataNasc.getText());

        usu.setNome(edtNome.getText());
        usu.setEmail(edtEmail.getText());
        usu.setSenha(lHashSenha);
        usu.setAtivo(chkAtivo.isSelected());
        usu.setDataNasc(dataNasc);

        //depois passo o objeto para o controller e ele irá gravar no banco de dados
        UsuarioController controller = new UsuarioController();

        if (controller.inserirUsuario(usu)) {
            String nomeUsuario = edtNome.getText();

            if (!nomeUsuario.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Usuário gravado com sucesso");
                FrMenu telaMenu = new FrMenu(nomeUsuario, "usuario");
                telaMenu.setVisible(true);
                this.dispose();  // Fecha a tela de cadastro ou login
            } else {
                JOptionPane.showMessageDialog(null, "O nome do usuário não foi informado.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "O cadastro não foi gravado.");
        }
    }

    public boolean verificarCampos() {
        //Se eu conseguir passar pelas validações retorna true

        //Nome - não pode ter números ou caracteres especiais, apenas letras e espaço
        //Email - ter um formato de email a@a.com
        //Senha - pelo menos 6 dígitos
        //Data - verificar se está no formato de data dd/mm/aaaa
        if (!edtNome.getText().matches("^[\\p{L} ]+$")) {//a-
            JOptionPane.showMessageDialog(null,
                    "O campo 'Nome' possui formato inválido");
            return false;
        }

        if (!edtEmail.getText().matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Email' possui formato inválido");
            return false;
        }

        if (new String(edtSenha.getPassword()).equals("")) {
            JOptionPane.showMessageDialog(null, "O campo 'Senha' em branco");
            return false;
        }

        String lSenha = new String(edtSenha.getPassword());
        String lConfirmaSenha = new String(edtConfirmaSenha.getPassword());

        if (!lSenha.equals(lConfirmaSenha)) {
            JOptionPane.showMessageDialog(null, "As senhas não são iguais");
            return false;
        }

        if (lSenha.length() < 6) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Senha' deve ter mais de 6 caracteres");
            return false;
        }

        if (edtDataNasc.getText().equals("")) {
            JOptionPane.showMessageDialog(null,
                    "O campo 'Data de Nascimento' em branco");
            return false;
        }

        return true;
    }

    private void formWindowOpened(java.awt.event.WindowEvent evt) {
        URL caminhoImagem = getClass().getResource("/images/logo_Waiter_Mini.png");

        if (caminhoImagem != null) {
            ImageIcon icon = new ImageIcon(caminhoImagem);
            this.setIconImage(icon.getImage());
        } else {
            System.out.println("Imagem não encontrada: /images/_logo_mini.png");
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrCadastroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FrCadastroCliente dialog = new FrCadastroCliente(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnConfirmaSenha;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JButton btnSenha;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JPasswordField edtConfirmaSenha;
    private javax.swing.JFormattedTextField edtDataNasc;
    private javax.swing.JTextField edtEmail;
    private javax.swing.JTextField edtNome;
    private javax.swing.JPasswordField edtSenha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblConfirmaSenha;
    private javax.swing.JLabel lblDataNasc;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSenha;
    private javax.swing.JLabel lblTitulo;
    // End of variables declaration//GEN-END:variables
}
